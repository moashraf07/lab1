<?php

namespace App\Exceptions;

use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Illuminate\Validation\ValidationException;
use Illuminate\Database\QueryException;
use Throwable;

class Handler extends ExceptionHandler
{
    /**
     * Map exception class → error category string.
     * Order matters: more specific first.
     */
    const CATEGORY_MAP = [
        ValidationException::class  => 'VALIDATION_ERROR',
        QueryException::class       => 'DATABASE_ERROR',
        \PDOException::class        => 'DATABASE_ERROR',
        \RuntimeException::class    => 'SYSTEM_ERROR',
        \LogicException::class      => 'SYSTEM_ERROR',
        \Exception::class           => 'UNKNOWN',
        \Throwable::class           => 'UNKNOWN',
    ];

    /**
     * Categorize an exception deterministically.
     */
    public function categorize(Throwable $e): string
    {
        foreach (self::CATEGORY_MAP as $class => $category) {
            if ($e instanceof $class) {
                return $category;
            }
        }
        return 'UNKNOWN';
    }

    /**
     * Render an exception into an HTTP response.
     * Attaches X-Error-Category + X-Error-Message headers
     * so TelemetryMiddleware can read them for logging/metrics.
     */
    public function render($request, Throwable $e)
    {
        $category = $this->categorize($e);

        $statusCode = match ($category) {
            'VALIDATION_ERROR' => 422,
            'DATABASE_ERROR'   => 503,
            'TIMEOUT_ERROR'    => 504,
            'SYSTEM_ERROR'     => 500,
            default            => 500,
        };

        // For ValidationException, use Laravel's built-in status
        if ($e instanceof ValidationException) {
            $statusCode = 422;
        }

        $body = [
            'status'         => 'error',
            'error_category' => $category,
            'message'        => $e->getMessage(),
            'timestamp'      => now()->toIso8601String(),
        ];

        if ($e instanceof ValidationException) {
            $body['errors'] = $e->errors();
        }

        $response = response()->json($body, $statusCode);

        // Attach headers for TelemetryMiddleware to consume
        $response->headers->set('X-Error-Category', $category);
        $response->headers->set('X-Error-Message', substr($e->getMessage(), 0, 200));

        return $response;
    }
}
