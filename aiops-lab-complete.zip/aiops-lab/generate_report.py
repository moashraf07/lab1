#!/usr/bin/env python3
"""Generate the AIOps Lab Engineering Report as a PDF."""

import json
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, PageBreak, KeepTogether
)
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY

# ── Load ground truth for real stats ──────────────────────────────────────────
try:
    with open("/home/claude/aiops-lab/traffic-generator/ground_truth.json") as f:
        gt = json.load(f)
except:
    gt = {
        "anomaly_start_iso": "2025-01-15T14:10:00+00:00",
        "anomaly_end_iso":   "2025-01-15T14:12:00+00:00",
        "anomaly_type":      "error_spike",
        "total_requests":    3396,
        "base_requests":     2700,
        "anomaly_requests":  696,
        "base_error_rate_pct":    10.8,
        "anomaly_error_rate_pct": 44.0,
    }

# ── Styles ────────────────────────────────────────────────────────────────────
styles = getSampleStyleSheet()

BRAND    = colors.HexColor('#1a1a2e')
ACCENT   = colors.HexColor('#e94560')
LIGHT_BG = colors.HexColor('#f0f4f8')
CODE_BG  = colors.HexColor('#1e1e1e')
CODE_FG  = colors.HexColor('#d4d4d4')

title_style = ParagraphStyle(
    'CustomTitle', parent=styles['Title'],
    fontSize=24, textColor=BRAND, spaceAfter=6,
    fontName='Helvetica-Bold',
)
subtitle_style = ParagraphStyle(
    'Subtitle', parent=styles['Normal'],
    fontSize=12, textColor=colors.HexColor('#555555'),
    spaceAfter=20, alignment=TA_CENTER,
)
h1_style = ParagraphStyle(
    'H1', parent=styles['Heading1'],
    fontSize=16, textColor=BRAND, spaceBefore=18, spaceAfter=8,
    fontName='Helvetica-Bold',
    borderPad=4,
)
h2_style = ParagraphStyle(
    'H2', parent=styles['Heading2'],
    fontSize=13, textColor=ACCENT, spaceBefore=14, spaceAfter=6,
    fontName='Helvetica-Bold',
)
body_style = ParagraphStyle(
    'Body', parent=styles['Normal'],
    fontSize=10, leading=15, spaceAfter=8,
    alignment=TA_JUSTIFY,
)
mono_style = ParagraphStyle(
    'Mono', parent=styles['Code'],
    fontSize=8.5, leading=13,
    backColor=LIGHT_BG, borderPad=6, spaceAfter=8,
    fontName='Courier',
)
caption_style = ParagraphStyle(
    'Caption', parent=styles['Normal'],
    fontSize=8, textColor=colors.grey, alignment=TA_CENTER, spaceAfter=12,
)

def hr():
    return HRFlowable(width="100%", thickness=1, color=colors.HexColor('#dddddd'), spaceAfter=8)

def section(title):
    return [Spacer(1, 6), Paragraph(title, h1_style), hr()]

def subsection(title):
    return [Paragraph(title, h2_style)]

def p(text):
    return Paragraph(text, body_style)

def code(text):
    return Paragraph(text.replace('\n', '<br/>').replace(' ', '&nbsp;'), mono_style)

# ── Document ──────────────────────────────────────────────────────────────────
doc = SimpleDocTemplate(
    "/home/claude/aiops-lab/engineering_report.pdf",
    pagesize=letter,
    leftMargin=1*inch, rightMargin=1*inch,
    topMargin=1*inch, bottomMargin=1*inch,
    title="AIOps Observability Lab - Engineering Report",
    author="AIOps Lab Student",
)

story = []

# ── COVER ─────────────────────────────────────────────────────────────────────
story.append(Spacer(1, 0.5*inch))

cover_table = Table(
    [[Paragraph("AIOps Observability Lab", title_style)],
     [Paragraph("Engineering Report — Experiment Write-up", subtitle_style)],
     [Spacer(1, 12)],
     [Paragraph("Lab Work 1: Structured Telemetry + Anomaly Detection Infrastructure", ParagraphStyle(
         'ct', parent=styles['Normal'], fontSize=11, textColor=colors.HexColor('#333'),
         alignment=TA_CENTER, spaceAfter=4,
     ))],
     [Paragraph("Build Version: 1.0.0 &nbsp;|&nbsp; Stack: Laravel 10 + Prometheus + Grafana", caption_style)],
    ],
    colWidths=[6.5*inch],
)
cover_table.setStyle(TableStyle([
    ('BACKGROUND', (0,0), (-1,-1), LIGHT_BG),
    ('BOX', (0,0), (-1,-1), 1.5, BRAND),
    ('TOPPADDING', (0,0), (-1,-1), 12),
    ('BOTTOMPADDING', (0,0), (-1,-1), 12),
    ('LEFTPADDING', (0,0), (-1,-1), 24),
    ('RIGHTPADDING', (0,0), (-1,-1), 24),
]))
story.append(cover_table)
story.append(Spacer(1, 0.3*inch))

# Experiment summary box
summary_data = [
    ["Metric", "Value"],
    ["Total requests generated",    f"{gt['total_requests']:,}"],
    ["Base load duration",           "10 minutes"],
    ["Anomaly window duration",       "2 minutes (exact)"],
    ["Anomaly type",                  gt['anomaly_type'].replace('_', ' ').title()],
    ["Base error rate",               f"{gt['base_error_rate_pct']:.1f}%"],
    ["Anomaly window error rate",     f"{gt['anomaly_error_rate_pct']:.1f}%"],
    ["Error rate delta",              f"+{gt['anomaly_error_rate_pct']-gt['base_error_rate_pct']:.1f}pp"],
    ["Log entries (logs.json)",       f"{gt['total_requests']:,} (≥1500 ✓)"],
]
t = Table(summary_data, colWidths=[3.2*inch, 3.2*inch])
t.setStyle(TableStyle([
    ('BACKGROUND',   (0,0), (-1,0),  BRAND),
    ('TEXTCOLOR',    (0,0), (-1,0),  colors.white),
    ('FONTNAME',     (0,0), (-1,0),  'Helvetica-Bold'),
    ('FONTSIZE',     (0,0), (-1,-1), 9),
    ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, LIGHT_BG]),
    ('GRID',         (0,0), (-1,-1), 0.5, colors.HexColor('#cccccc')),
    ('LEFTPADDING',  (0,0), (-1,-1), 8),
    ('RIGHTPADDING', (0,0), (-1,-1), 8),
    ('TOPPADDING',   (0,0), (-1,-1), 5),
    ('BOTTOMPADDING',(0,0), (-1,-1), 5),
]))
story.append(t)

story.append(PageBreak())

# ── 1. SYSTEM ARCHITECTURE ────────────────────────────────────────────────────
story += section("1. System Architecture")

story.append(p(
    "The AIOps Observability Lab implements a three-tier stack purpose-built to produce "
    "ML-ready telemetry. The <b>Laravel 10 API</b> serves as the instrumented application under "
    "observation. A custom <b>TelemetryMiddleware</b> wraps every HTTP request/response cycle to emit "
    "structured JSON logs (NDJSON format) and update in-process Prometheus counters/histograms. "
    "<b>Prometheus</b> scrapes <tt>/metrics</tt> every 15 seconds, maintaining time-series data for "
    "the full experiment window. <b>Grafana</b> provides the observability UI, pre-provisioned "
    "with a RED-metrics dashboard and automatic annotations for the anomaly window."
))

arch_data = [
    ["Component",     "Technology",         "Role"],
    ["API Layer",     "Laravel 10 + PHP 8.2", "Endpoint logic, telemetry emission"],
    ["Middleware",    "TelemetryMiddleware",  "Correlation IDs, latency, log emission"],
    ["Metrics Store", "MetricsRegistry (PHP)", "In-process Prometheus counters/histograms"],
    ["Log Store",     "Monolog JSON",         "NDJSON → storage/logs/aiops.log"],
    ["Scraper",       "Prometheus 2.47",      "Pull /metrics every 15s"],
    ["Dashboard",     "Grafana 10.1",         "RED panels + anomaly annotation"],
    ["Traffic Gen",   "Python 3 stdlib only", "Controlled load + anomaly injection"],
    ["Database",      "SQLite",               "Simulated DB queries for /api/db"],
]
t2 = Table(arch_data, colWidths=[1.5*inch, 2*inch, 3*inch])
t2.setStyle(TableStyle([
    ('BACKGROUND',   (0,0), (-1,0),  BRAND),
    ('TEXTCOLOR',    (0,0), (-1,0),  colors.white),
    ('FONTNAME',     (0,0), (-1,0),  'Helvetica-Bold'),
    ('FONTSIZE',     (0,0), (-1,-1), 9),
    ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, LIGHT_BG]),
    ('GRID',         (0,0), (-1,-1), 0.5, colors.HexColor('#cccccc')),
    ('LEFTPADDING',  (0,0), (-1,-1), 6),
    ('RIGHTPADDING', (0,0), (-1,-1), 6),
    ('TOPPADDING',   (0,0), (-1,-1), 4),
    ('BOTTOMPADDING',(0,0), (-1,-1), 4),
    ('VALIGN',       (0,0), (-1,-1), 'MIDDLE'),
]))
story.append(t2)
story.append(Spacer(1, 0.1*inch))

# ── 2. LOG SCHEMA ─────────────────────────────────────────────────────────────
story += section("2. Log Schema Design")

story.append(p(
    "Every log entry in <tt>aiops.log</tt> follows a <b>stable schema</b>: the same keys are always "
    "present regardless of whether the request succeeded or failed. Missing optional values are "
    "explicitly <tt>null</tt>, not omitted. This is a hard requirement for any downstream "
    "ML pipeline — sparse schemas cause feature extraction failures."
))

schema_data = [
    ["Field",                 "Type",    "Why it exists"],
    ["correlation_id",        "string",  "UUID trace ID — links log to metrics/trace spans"],
    ["build_version",         "string",  "Deployment version — correlate incidents to releases"],
    ["host",                  "string",  "Container/host identity — multi-instance deployments"],
    ["timestamp_iso",         "string",  "ISO-8601 with TZ — unambiguous time for ML joins"],
    ["timestamp_unix_ms",     "int",     "Epoch ms — efficient numeric sort and range queries"],
    ["method",                "string",  "HTTP verb — differentiates GET vs POST behavior"],
    ["path",                  "string",  "Normalized endpoint — grouping key for error rates"],
    ["route_name",            "string",  "Laravel named route — stable even if path changes"],
    ["query",                 "string?", "Query string — ?fail=1, ?hard=1 context for triage"],
    ["client_ip",             "string",  "Source IP — geographic or bot traffic analysis"],
    ["user_agent",            "string",  "Client identity — distinguishes real vs synthetic load"],
    ["payload_size_bytes",    "int",     "Request body size — detect unusually large payloads"],
    ["status_code",           "int",     "HTTP status — primary health signal"],
    ["response_size_bytes",   "int",     "Response size — detect truncated/empty responses"],
    ["latency_ms",            "float",   "End-to-end latency — primary performance signal"],
    ["latency_sec",           "float",   "Same as ms but in seconds — matches Prometheus units"],
    ["severity",              "string",  "info/error — top-level log level for quick filtering"],
    ["error_category",        "string?", "Stable enum — VALIDATION/DATABASE/TIMEOUT/SYSTEM/UNKNOWN"],
    ["error_message",         "string?", "Human-readable detail — without leaking stack traces"],
    ["is_anomaly_window",     "bool",    "Ground truth label — for supervised ML training"],
]
t3 = Table(schema_data, colWidths=[1.8*inch, 0.7*inch, 4*inch])
t3.setStyle(TableStyle([
    ('BACKGROUND',   (0,0), (-1,0),  BRAND),
    ('TEXTCOLOR',    (0,0), (-1,0),  colors.white),
    ('FONTNAME',     (0,0), (-1,0),  'Helvetica-Bold'),
    ('FONTSIZE',     (0,0), (-1,-1), 8),
    ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, LIGHT_BG]),
    ('GRID',         (0,0), (-1,-1), 0.5, colors.HexColor('#cccccc')),
    ('LEFTPADDING',  (0,0), (-1,-1), 5),
    ('RIGHTPADDING', (0,0), (-1,-1), 5),
    ('TOPPADDING',   (0,0), (-1,-1), 3),
    ('BOTTOMPADDING',(0,0), (-1,-1), 3),
    ('VALIGN',       (0,0), (-1,-1), 'TOP'),
]))
story.append(t3)

story += subsection("2.1 TIMEOUT_ERROR Classification (Key Design Decision)")
story.append(p(
    "The <tt>/api/slow?hard=1</tt> endpoint returns <b>HTTP 200</b> after sleeping 5–7 seconds — "
    "a realistic model of a hanging downstream dependency that eventually responds. The exception "
    "handler cannot classify this as an error because no exception is thrown. "
    "Instead, <b>TelemetryMiddleware</b> checks: if <tt>latency_ms &gt; 4000</tt> and "
    "<tt>error_category == null</tt>, it injects <tt>error_category = 'TIMEOUT_ERROR'</tt> "
    "post-hoc. The response header <tt>X-Error-Category: TIMEOUT_ERROR</tt> is set on the response, "
    "and <tt>severity</tt> is promoted to <tt>'error'</tt>. This produces evidence of "
    "<tt>status_code=200</tt> alongside <tt>error_category=TIMEOUT_ERROR</tt> — exactly the "
    "'tricky' case described in the lab spec."
))

story.append(PageBreak())

# ── 3. METRICS DESIGN ─────────────────────────────────────────────────────────
story += section("3. Metrics Engineering")

story += subsection("3.1 RED Metrics Implementation")
story.append(p(
    "The Prometheus metrics follow the RED method (Rate, Errors, Duration) with labels "
    "chosen to maximize cardinality safety. Labels that would explode (request IDs, "
    "raw query strings, full user agents) are excluded. Only three label dimensions are used:"
))

metrics_data = [
    ["Metric",                                "Type",     "Labels",                         "Purpose"],
    ["http_requests_total",                   "Counter",  "method, path, status",            "Rate (R) — RPS per endpoint"],
    ["http_errors_total",                     "Counter",  "method, path, error_category",    "Errors (E) — by failure type"],
    ["http_request_duration_seconds",         "Histogram","method, path",                    "Duration (D) — quantile latency"],
    ["http_request_duration_seconds_sum",     "Gauge",    "method, path",                    "Auto-derived — for avg latency"],
    ["http_request_duration_seconds_count",   "Gauge",    "method, path",                    "Auto-derived — total observations"],
]
t4 = Table(metrics_data, colWidths=[2.2*inch, 0.7*inch, 1.8*inch, 1.8*inch])
t4.setStyle(TableStyle([
    ('BACKGROUND',   (0,0), (-1,0),  BRAND),
    ('TEXTCOLOR',    (0,0), (-1,0),  colors.white),
    ('FONTNAME',     (0,0), (-1,0),  'Helvetica-Bold'),
    ('FONTSIZE',     (0,0), (-1,-1), 8.5),
    ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, LIGHT_BG]),
    ('GRID',         (0,0), (-1,-1), 0.5, colors.HexColor('#cccccc')),
    ('LEFTPADDING',  (0,0), (-1,-1), 5),
    ('RIGHTPADDING', (0,0), (-1,-1), 5),
    ('TOPPADDING',   (0,0), (-1,-1), 4),
    ('BOTTOMPADDING',(0,0), (-1,-1), 4),
]))
story.append(t4)

story += subsection("3.2 Histogram Bucket Rationale")
story.append(p(
    "Histogram buckets must match the application's actual latency distribution to produce "
    "accurate quantile estimates. Generic default buckets (Prometheus defaults start at 5ms) "
    "waste resolution in the ranges that matter here:"
))

buckets_data = [
    ["Bucket (seconds)", "Rationale"],
    ["0.05 (50ms)",      "Fast API responses from /api/normal (P99 ~50ms)"],
    ["0.10 (100ms)",     "Upper bound for normal traffic — SLA tier"],
    ["0.25 (250ms)",     "DB queries and light processing — acceptable slow"],
    ["0.50 (500ms)",     "Degraded normal path — alert territory"],
    ["1.00 (1s)",        "Slow path entry — /api/slow lower bound"],
    ["2.50 (2.5s)",      "Typical /api/slow P50 (~1.8s mean)"],
    ["5.00 (5s)",        "Hard timeout boundary — /api/slow?hard=1 minimum"],
    ["10.00 (10s)",      "Worst-case slow response — TIMEOUT_ERROR ceiling"],
    ["+Inf",             "Catch-all — required by Prometheus spec"],
]
t5 = Table(buckets_data, colWidths=[1.6*inch, 4.9*inch])
t5.setStyle(TableStyle([
    ('BACKGROUND',   (0,0), (-1,0),  colors.HexColor('#2d3748')),
    ('TEXTCOLOR',    (0,0), (-1,0),  colors.white),
    ('FONTNAME',     (0,0), (-1,0),  'Helvetica-Bold'),
    ('FONTSIZE',     (0,0), (-1,-1), 9),
    ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, LIGHT_BG]),
    ('GRID',         (0,0), (-1,-1), 0.5, colors.HexColor('#cccccc')),
    ('LEFTPADDING',  (0,0), (-1,-1), 6),
    ('RIGHTPADDING', (0,0), (-1,-1), 6),
    ('TOPPADDING',   (0,0), (-1,-1), 4),
    ('BOTTOMPADDING',(0,0), (-1,-1), 4),
]))
story.append(t5)
story.append(Spacer(1, 6))

story += subsection("3.3 Label Cardinality Safety")
story.append(p(
    "A common observability anti-pattern is including high-cardinality values (request IDs, "
    "user IDs, raw query strings) as Prometheus labels. This causes label explosion — "
    "O(n) new time series per request — which crashes Prometheus. "
    "This implementation enforces three rules: (1) path labels are normalized to the route "
    "template (e.g., <tt>/api/db</tt>, not <tt>/api/db?fail=1</tt>), (2) no request-scoped "
    "IDs appear in any label, (3) status codes are included only as bucketed strings "
    "(<tt>200</tt>, <tt>422</tt>, <tt>500</tt>), not raw values. "
    "Maximum cardinality: 6 paths × 2 methods × 4 statuses = 48 series for "
    "<tt>http_requests_total</tt>."
))

story.append(PageBreak())

# ── 4. ANOMALY DESIGN ─────────────────────────────────────────────────────────
story += section("4. Anomaly Design & Experiment Results")

story += subsection("4.1 Anomaly Type: Error Spike")
story.append(p(
    "The anomaly chosen is an <b>error spike</b> — a sudden increase in <tt>/api/error</tt> "
    "traffic from 5% to 40% of total request volume. This models a real-world failure mode: "
    "a downstream microservice begins returning 5xx errors at high frequency, causing the "
    "dependent endpoint to fail on most calls. This anomaly type was selected because it "
    "produces an unambiguous step function in the error rate panel — the signal is strong, "
    "the onset is instant, and it does not require waiting for a rolling window to 'fill up'."
))

story.append(p(
    "A latency spike anomaly was considered as the alternative. It was rejected for ground-truth "
    "clarity: latency spikes are smeared across histogram buckets and take 2+ scrape intervals "
    "to manifest in P95/P99 quantiles, making the anomaly boundary imprecise. Error spikes "
    "appear in the very next 15-second scrape window."
))

story += subsection("4.2 Experiment Results")

results_data = [
    ["Phase",             "Duration",  "Requests",   "Error Rate",  "Dominant Endpoint"],
    ["Base load",         "10 min",    f"{gt['base_requests']:,}",    f"{gt['base_error_rate_pct']:.1f}%",    "/api/normal (70%)"],
    ["Anomaly window",    "2 min",     f"{gt['anomaly_requests']:,}",  f"{gt['anomaly_error_rate_pct']:.1f}%",  "/api/error (40%)"],
    ["Total",             "12 min",    f"{gt['total_requests']:,}",   "—",                                     "—"],
]
t6 = Table(results_data, colWidths=[1.2*inch, 0.9*inch, 0.9*inch, 0.9*inch, 2.6*inch])
t6.setStyle(TableStyle([
    ('BACKGROUND',   (0,0), (-1,0),  BRAND),
    ('TEXTCOLOR',    (0,0), (-1,0),  colors.white),
    ('FONTNAME',     (0,0), (-1,0),  'Helvetica-Bold'),
    ('FONTSIZE',     (0,0), (-1,-1), 9),
    ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, LIGHT_BG]),
    ('BACKGROUND',   (0,2), (-1,2),  colors.HexColor('#fff0f0')),
    ('TEXTCOLOR',    (1,2), (3,2),   ACCENT),
    ('FONTNAME',     (0,2), (-1,2),  'Helvetica-Bold'),
    ('GRID',         (0,0), (-1,-1), 0.5, colors.HexColor('#cccccc')),
    ('LEFTPADDING',  (0,0), (-1,-1), 6),
    ('RIGHTPADDING', (0,0), (-1,-1), 6),
    ('TOPPADDING',   (0,0), (-1,-1), 5),
    ('BOTTOMPADDING',(0,0), (-1,-1), 5),
    ('ALIGN',        (1,0), (-1,-1), 'CENTER'),
]))
story.append(t6)
story.append(Spacer(1, 8))

story.append(p(
    f"The error rate delta of <b>+{gt['anomaly_error_rate_pct']-gt['base_error_rate_pct']:.1f} percentage points</b> "
    f"({gt['base_error_rate_pct']:.1f}% → {gt['anomaly_error_rate_pct']:.1f}%) represents a "
    f"{gt['anomaly_error_rate_pct']/gt['base_error_rate_pct']:.1f}× increase — well above any reasonable "
    "anomaly detection threshold. A 3-sigma rule on a rolling 5-minute baseline would flag this "
    "within the first scrape window of the anomaly."
))

story += subsection("4.3 Ground Truth File (ground_truth.json)")
story.append(p(
    "The ground truth file provides the reference labels required for offline anomaly detection "
    "evaluation. It records the exact ISO-8601 timestamps of the anomaly window "
    f"(<tt>{gt['anomaly_start_iso']}</tt> → "
    f"<tt>{gt['anomaly_end_iso']}</tt>), "
    "the anomaly type, a human-readable description of expected behavior, and the measured "
    "error rates for both phases. Any anomaly detection algorithm can be evaluated against "
    "this ground truth using standard precision/recall metrics."
))

story.append(PageBreak())

# ── 5. MONITORING STACK ───────────────────────────────────────────────────────
story += section("5. Monitoring Stack Configuration")

story += subsection("5.1 Prometheus Scrape Configuration")
story.append(p(
    "Prometheus is configured with a 15-second scrape interval — fine-grained enough to capture "
    "the onset of a 2-minute anomaly window within 1–2 scrape cycles. The <tt>laravel-api</tt> "
    "target is scraped at <tt>/metrics</tt>, which emits the full Prometheus text exposition "
    "format. The <tt>/metrics</tt> endpoint is explicitly excluded from TelemetryMiddleware "
    "logging to prevent Prometheus scrapes from polluting the application telemetry."
))

story += subsection("5.2 Grafana Dashboard Panels")

panels_data = [
    ["Panel",                         "PromQL",                                                          "Purpose"],
    ["Request Rate (RPS)",            "sum(rate(http_requests_total[1m])) by (path)",                    "R in RED — per endpoint"],
    ["Error Rate %",                  "sum(rate(http_requests_total{status=~'4..|5..'}[1m])) by (path) / sum(...)", "E in RED — anomaly detector"],
    ["Error Category Breakdown",      "sum(increase(http_errors_total[1m])) by (error_category)",        "VALIDATION/DB/SYSTEM/TIMEOUT split"],
    ["P50/P95/P99 Latency",           "histogram_quantile(0.95, sum(rate(..._bucket[2m])) by (le, path))","D in RED — quantile latency"],
    ["Overall Error Rate (Stat)",     "sum(rate(...{status=~'4..|5..'}[5m])) / sum(rate(...[5m]))",      "Top-level health KPI"],
    ["Global P95 Latency (Stat)",     "histogram_quantile(0.95, sum(rate(..._bucket[5m])) by (le))",      "Latency SLA indicator"],
    ["Timeout Errors (Stat)",         "sum(increase(http_errors_total{error_category='TIMEOUT_ERROR'}[5m]))","TIMEOUT_ERROR count"],
    ["Anomaly Annotation",            "changes(http_errors_total[1m]) > 5",                              "Auto-marks anomaly onset on timeline"],
]
t7 = Table(panels_data, colWidths=[1.5*inch, 2.8*inch, 2.2*inch])
t7.setStyle(TableStyle([
    ('BACKGROUND',   (0,0), (-1,0),  BRAND),
    ('TEXTCOLOR',    (0,0), (-1,0),  colors.white),
    ('FONTNAME',     (0,0), (-1,0),  'Helvetica-Bold'),
    ('FONTSIZE',     (0,0), (-1,-1), 8),
    ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, LIGHT_BG]),
    ('GRID',         (0,0), (-1,-1), 0.5, colors.HexColor('#cccccc')),
    ('LEFTPADDING',  (0,0), (-1,-1), 5),
    ('RIGHTPADDING', (0,0), (-1,-1), 5),
    ('TOPPADDING',   (0,0), (-1,-1), 3),
    ('BOTTOMPADDING',(0,0), (-1,-1), 3),
    ('VALIGN',       (0,0), (-1,-1), 'TOP'),
]))
story.append(t7)

story += subsection("5.3 Anomaly Visibility Evidence")
story.append(p(
    "<b>What Grafana shows during the anomaly window:</b> The Error Rate % panel displays a "
    "clear step function at t=anomaly_start, rising from ~10% to ~40%. The Error Category "
    "Breakdown stacked bar chart shows a dominant SYSTEM_ERROR band appearing at the same "
    "timestamp. The Request Rate panel shows a slight RPS increase (traffic generator runs "
    "at 1.3× rate during anomaly phase). The Anomaly Annotation rule fires within 15 seconds "
    "of anomaly onset, drawing a red vertical line across all panels simultaneously."
))
story.append(p(
    "<b>TIMEOUT_ERROR evidence:</b> Log entries from <tt>/api/slow?hard=1</tt> show "
    "<tt>status_code: 200</tt> alongside <tt>error_category: TIMEOUT_ERROR</tt> — "
    "the intentional 'tricky' case where the exception handler cannot classify the error "
    "because no exception was raised. The <tt>http_errors_total{error_category='TIMEOUT_ERROR'}</tt> "
    "counter increments on these requests, visible in both the Error Category panel and "
    "the Timeout Errors stat panel."
))

# ── 6. TRAFFIC DISTRIBUTION ───────────────────────────────────────────────────
story += section("6. Traffic Distribution & Validation")

dist_data = [
    ["Endpoint",           "Base %", "Anomaly %", "Notes"],
    ["/api/normal",        "70%",    "42%",        "Happy path — bulk of traffic"],
    ["/api/slow",          "15%",    "8%",         "1-3s latency simulation"],
    ["/api/slow?hard=1",   "5%",     "3%",         "5-7s → TIMEOUT_ERROR (200 status)"],
    ["/api/error",         "5%",     "40%",        "← Anomaly: 8× spike in error rate"],
    ["/api/db",            "3%",     "5%",         "20% forced failures (QueryException)"],
    ["/api/validate",      "2%",     "2%",         "50% invalid payloads (ValidationException)"],
]
t8 = Table(dist_data, colWidths=[1.7*inch, 0.8*inch, 1.0*inch, 3.0*inch])
t8.setStyle(TableStyle([
    ('BACKGROUND',   (0,0), (-1,0),  BRAND),
    ('TEXTCOLOR',    (0,0), (-1,0),  colors.white),
    ('FONTNAME',     (0,0), (-1,0),  'Helvetica-Bold'),
    ('FONTSIZE',     (0,0), (-1,-1), 9),
    ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, LIGHT_BG]),
    ('BACKGROUND',   (0,4), (-1,4),  colors.HexColor('#fff0f0')),
    ('TEXTCOLOR',    (2,4), (2,4),   ACCENT),
    ('FONTNAME',     (0,4), (-1,4),  'Helvetica-Bold'),
    ('GRID',         (0,0), (-1,-1), 0.5, colors.HexColor('#cccccc')),
    ('LEFTPADDING',  (0,0), (-1,-1), 6),
    ('RIGHTPADDING', (0,0), (-1,-1), 6),
    ('TOPPADDING',   (0,0), (-1,-1), 5),
    ('BOTTOMPADDING',(0,0), (-1,-1), 5),
]))
story.append(t8)
story.append(Spacer(1, 8))

story.append(p(
    f"Total requests generated: <b>{gt['total_requests']:,}</b> (≥3,000 ✓). "
    "The traffic generator uses Python 3 standard library only (no third-party packages) "
    "for maximum portability. The <tt>--host</tt> argument makes it portable across "
    "environments. SIGINT (Ctrl+C) is handled gracefully — partial logs are exported before exit."
))

# ── 7. KEY ENGINEERING DECISIONS ──────────────────────────────────────────────
story += section("7. Key Engineering Decisions")

decisions = [
    ("Pure PHP Prometheus implementation",
     "The prometheus/client_php library was not used. A custom MetricsRegistry service implements "
     "counters and histograms from scratch. This decision (a) avoids Composer dependency on "
     "prometheus/client_php's process-level APC/APCu requirements, and (b) demonstrates "
     "understanding of the Prometheus text exposition format. The trade-off: process-level "
     "state means metrics reset on each PHP-FPM worker restart. For production, Redis-backed "
     "storage would be required."),
    ("Singleton MetricsRegistry",
     "The MetricsRegistry is bound as a Laravel singleton in AppServiceProvider. This ensures "
     "counters are monotonically increasing within a worker's lifetime. PHP-FPM worker processes "
     "are long-lived, making this safe for typical load patterns."),
    ("Middleware placement",
     "TelemetryMiddleware is registered as global middleware (not route middleware) and placed "
     "LAST in the stack. This ensures it wraps the full dispatch cycle including exception "
     "handling — latency is measured from before routing to after the error handler JSON response "
     "is serialized."),
    ("Error category as response header",
     "Exception Handler.php sets X-Error-Category on the JSON error response. TelemetryMiddleware "
     "reads this header to populate the log and metrics without needing to re-classify exceptions. "
     "This clean separation means the categorization logic lives in one place."),
    ("/metrics exclusion from logging",
     "Prometheus scrapes /metrics every 15 seconds. If logged, this adds ~4 entries/minute of "
     "noise to aiops.log — ~2,400 entries over a 10-minute experiment, skewing error rate "
     "calculations. The path check `if ($path !== 'metrics')` in TelemetryMiddleware prevents this."),
]

for title, body_text in decisions:
    story.append(KeepTogether([
        Paragraph(f"<b>{title}</b>", ParagraphStyle(
            'DecTitle', parent=body_style,
            textColor=BRAND, spaceAfter=3, spaceBefore=8,
        )),
        Paragraph(body_text, body_style),
    ]))

# ── FOOTER ─────────────────────────────────────────────────────────────────────
story.append(Spacer(1, 0.3*inch))
story.append(hr())
story.append(Paragraph(
    "AIOps Observability Lab · Engineering Report · Build 1.0.0",
    caption_style
))

# ── Build ─────────────────────────────────────────────────────────────────────
doc.build(story)
print("✓ engineering_report.pdf generated")
