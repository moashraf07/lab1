<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use App\Services\MetricsService;
use Symfony\Component\HttpFoundation\Response;

class TelemetryMiddleware
{
    protected MetricsService $metrics;

    // Latency threshold above which we classify as TIMEOUT_ERROR (ms)
    const TIMEOUT_THRESHOLD_MS = 4000;

    public function __construct(MetricsService $metrics)
    {
        $this->metrics = $metrics;
    }

    public function handle(Request $request, Closure $next): Response
    {
        // ─── Correlation ID propagation ───────────────────────────────────────
        $correlationId = $request->header('X-Request-Id') ?: (string) Str::uuid();

        // Start timer
        $startTime = microtime(true);

        // ─── Forward the request ─────────────────────────────────────────────
        /** @var Response $response */
        $response = $next($request);

        // ─── Compute latency ─────────────────────────────────────────────────
        $latencyMs      = (microtime(true) - $startTime) * 1000;
        $latencySeconds = $latencyMs / 1000;

        // ─── Attach correlation ID to response ───────────────────────────────
        $response->headers->set('X-Request-Id', $correlationId);

        // ─── Derive contextual metadata ──────────────────────────────────────
        $statusCode    = $response->getStatusCode();
        $method        = strtoupper($request->method());
        $routeName     = optional($request->route())->getName() ?? 'unknown';
        $path          = $this->normalizePath($request);
        $errorCategory = $response->headers->get('X-Error-Category', null);

        // Timeout override: if latency exceeds threshold, force TIMEOUT_ERROR
        // even when response is HTTP 200 (hard-slow scenario)
        if ($latencyMs >= self::TIMEOUT_THRESHOLD_MS && $errorCategory === null) {
            $errorCategory = 'TIMEOUT_ERROR';
        }

        $severity = ($statusCode >= 400 || $errorCategory !== null) ? 'error' : 'info';

        // ─── Build log record (stable schema – all keys always present) ───────
        $logRecord = [
            // Identifiers
            'correlation_id'        => $correlationId,
            'host'                  => gethostname() ?: 'unknown',
            'build_version'         => env('BUILD_VERSION', '1.0.0'),

            // Request
            'method'                => $method,
            'path'                  => $path,
            'route_name'            => $routeName,
            'query'                 => $request->getQueryString() ?? '',
            'payload_size_bytes'    => (int) $request->header('Content-Length', strlen($request->getContent())),
            'client_ip'             => $request->ip() ?? 'unknown',
            'user_agent'            => $request->userAgent() ?? 'unknown',

            // Response
            'status_code'           => $statusCode,
            'response_size_bytes'   => strlen($response->getContent()),
            'latency_ms'            => round($latencyMs, 3),

            // Error
            'error_category'        => $errorCategory,
            'error_message'         => $response->headers->get('X-Error-Message', null),

            // Observability
            'severity'              => $severity,
            'timestamp'             => now()->toIso8601String(),
        ];

        // ─── Write structured log ────────────────────────────────────────────
        if ($severity === 'error') {
            Log::channel('aiops')->error('request_completed', $logRecord);
        } else {
            Log::channel('aiops')->info('request_completed', $logRecord);
        }

        // ─── Update Prometheus metrics ────────────────────────────────────────
        $this->metrics->incrementRequestTotal($method, $path, $statusCode);
        $this->metrics->observeRequestDuration($method, $path, $latencySeconds);

        if ($statusCode >= 400 || $errorCategory !== null) {
            $cat = $errorCategory ?? 'UNKNOWN';
            $this->metrics->incrementErrorTotal($method, $path, $cat);
        }

        return $response;
    }

    /**
     * Normalize path for Prometheus labels: avoid high-cardinality (no query strings, no IDs)
     */
    protected function normalizePath(Request $request): string
    {
        $path = '/' . ltrim($request->path(), '/');

        // Strip /api prefix for cleaner labels
        $path = preg_replace('#^/api#', '', $path);

        // Normalise dynamic IDs: /users/123 → /users/{id}
        $path = preg_replace('#/\d+#', '/{id}', $path);

        return $path ?: '/';
    }
}
