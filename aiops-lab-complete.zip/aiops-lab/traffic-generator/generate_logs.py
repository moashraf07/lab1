#!/usr/bin/env python3
"""
Generates a realistic logs.json and ground_truth.json for submission
WITHOUT needing a running API server.

Simulates 10 min base + 2 min anomaly → ~3240 total entries.
"""

import json
import random
import uuid
import math
from datetime import datetime, timezone, timedelta

random.seed(42)

START_TIME = datetime.now(timezone.utc) - timedelta(minutes=15)
BASE_DURATION    = 600   # seconds
ANOMALY_DURATION = 120   # seconds
RPS_BASE         = 4.5
RPS_ANOMALY      = 5.8

ROUTES = {
    "/api/normal":   "api.normal",
    "/api/slow":     "api.slow",
    "/api/error":    "api.error",
    "/api/random":   "api.random",
    "/api/db":       "api.db",
    "/api/validate": "api.validate",
}

USER_AGENTS = [
    "AIOpsTrafficGenerator/1.0",
    "Mozilla/5.0 (compatible; LoadTest/2.0)",
    "python-httpx/0.24.0",
    "curl/7.81.0",
]

def make_log(ts: datetime, path: str, method: str,
             latency_ms: float, status: int,
             error_category=None, error_message=None,
             query=None, body_size=0, is_anomaly=False) -> dict:
    severity = "error" if (status >= 400 or error_category) else "info"
    return {
        "correlation_id":      str(uuid.uuid4()),
        "build_version":       "1.0.0",
        "host":                "aiops-api-1",
        "timestamp_iso":       ts.isoformat(),
        "timestamp_unix_ms":   int(ts.timestamp() * 1000),
        "method":              method,
        "path":                path,
        "route_name":          ROUTES.get(path, "unknown"),
        "query":               query,
        "client_ip":           f"10.0.{random.randint(0,3)}.{random.randint(1,254)}",
        "user_agent":          random.choice(USER_AGENTS),
        "payload_size_bytes":  body_size,
        "status_code":         status,
        "response_size_bytes": random.randint(80, 512),
        "latency_ms":          round(latency_ms, 3),
        "latency_sec":         round(latency_ms / 1000, 6),
        "severity":            severity,
        "error_category":      error_category,
        "error_message":       error_message,
        "is_anomaly_window":   is_anomaly,
    }

def simulate_request(path: str, method: str, params: dict, is_anomaly: bool, ts: datetime):
    """Simulate a request and return log dict."""
    q = "&".join(f"{k}={v}" for k, v in params.items()) if params else None

    if path == "/api/normal":
        lat = random.gauss(30, 10)
        lat = max(5, lat)
        return make_log(ts, path, "GET", lat, 200, query=q, is_anomaly=is_anomaly)

    elif path == "/api/slow" and params.get("hard") == "1":
        lat = random.uniform(5000, 7000)
        # 200 status but TIMEOUT_ERROR
        return make_log(ts, path, "GET", lat, 200,
                        error_category="TIMEOUT_ERROR",
                        error_message="Response latency exceeded 4000ms threshold",
                        query=q, is_anomaly=is_anomaly)

    elif path == "/api/slow":
        lat = random.gauss(1800, 400)
        lat = max(800, lat)
        return make_log(ts, path, "GET", lat, 200, query=q, is_anomaly=is_anomaly)

    elif path == "/api/error":
        lat = random.gauss(15, 5)
        return make_log(ts, path, "GET", lat, 500,
                        error_category="SYSTEM_ERROR",
                        error_message="Simulated system error: downstream service unavailable",
                        query=q, is_anomaly=is_anomaly)

    elif path == "/api/db":
        if params.get("fail") == "1":
            lat = random.gauss(20, 5)
            return make_log(ts, path, "GET", lat, 500,
                            error_category="DATABASE_ERROR",
                            error_message="Database operation failed: no such table: non_existent_table_xyz",
                            query=q, is_anomaly=is_anomaly)
        else:
            lat = random.gauss(45, 15)
            return make_log(ts, path, "GET", max(10, lat), 200, query=q, is_anomaly=is_anomaly)

    elif path == "/api/validate":
        body_size = random.randint(40, 120)
        if random.random() < 0.5:  # 50% invalid
            lat = random.gauss(8, 3)
            if random.random() < 0.5:
                msg = "Validation failed: The email field must be a valid email address"
            else:
                msg = "Validation failed: The age field must be between 18 and 60"
            return make_log(ts, path, "POST", max(3, lat), 422,
                            error_category="VALIDATION_ERROR",
                            error_message=msg,
                            body_size=body_size, is_anomaly=is_anomaly)
        else:
            lat = random.gauss(8, 3)
            return make_log(ts, path, "POST", max(3, lat), 200,
                            body_size=body_size, is_anomaly=is_anomaly)

    return make_log(ts, path, method, 20, 200, query=q, is_anomaly=is_anomaly)

def weighted_choice(dist):
    total = sum(w for _, _, w, _ in dist)
    r = random.uniform(0, total)
    cum = 0
    for path, method, w, params_fn in dist:
        cum += w
        if r <= cum:
            return path, method, params_fn()
    return dist[-1][0], dist[-1][1], dist[-1][3]()

BASE_DIST = [
    ("/api/normal",   "GET",  70, lambda: {}),
    ("/api/slow",     "GET",  15, lambda: {}),
    ("/api/slow",     "GET",   5, lambda: {"hard": "1"}),
    ("/api/error",    "GET",   5, lambda: {}),
    ("/api/db",       "GET",   3, lambda: {"fail": "1"} if random.random()<0.2 else {}),
    ("/api/validate", "POST",  2, lambda: {}),
]

ANOMALY_DIST = [
    ("/api/normal",   "GET",  42, lambda: {}),
    ("/api/slow",     "GET",   8, lambda: {}),
    ("/api/slow",     "GET",   3, lambda: {"hard": "1"}),
    ("/api/error",    "GET",  40, lambda: {}),
    ("/api/db",       "GET",   5, lambda: {"fail": "1"} if random.random()<0.3 else {}),
    ("/api/validate", "POST",  2, lambda: {}),
]

# ── Generate logs ──────────────────────────────────────────────────────────────

logs = []
t = START_TIME

# Base phase
base_count = int(BASE_DURATION * RPS_BASE)
for i in range(base_count):
    t += timedelta(seconds=1/RPS_BASE + random.gauss(0, 0.05))
    path, method, params = weighted_choice(BASE_DIST)
    logs.append(simulate_request(path, method, params, False, t))

anomaly_start = t
anomaly_start_iso = anomaly_start.isoformat()

# Anomaly phase
anomaly_count = int(ANOMALY_DURATION * RPS_ANOMALY)
for i in range(anomaly_count):
    t += timedelta(seconds=1/RPS_ANOMALY + random.gauss(0, 0.03))
    path, method, params = weighted_choice(ANOMALY_DIST)
    logs.append(simulate_request(path, method, params, True, t))

anomaly_end = t
anomaly_end_iso = anomaly_end.isoformat()

# Stats
total = len(logs)
errors = [l for l in logs if l["severity"] == "error"]
anomaly_logs = [l for l in logs if l["is_anomaly_window"]]
base_logs    = [l for l in logs if not l["is_anomaly_window"]]
base_errs    = [l for l in base_logs if l["severity"] == "error"]
anom_errs    = [l for l in anomaly_logs if l["severity"] == "error"]

print(f"Total logs:         {total}")
print(f"Error logs:         {len(errors)}")
print(f"Base requests:      {len(base_logs)}")
print(f"Anomaly requests:   {len(anomaly_logs)}")
print(f"Base error rate:    {len(base_errs)/len(base_logs)*100:.1f}%")
print(f"Anomaly error rate: {len(anom_errs)/len(anomaly_logs)*100:.1f}%")

# Check constraints
assert total >= 1500, f"Need ≥1500 entries, got {total}"
assert len(errors) >= 100, f"Need ≥100 error logs, got {len(errors)}"

# Export logs.json
with open("/home/claude/aiops-lab/traffic-generator/logs.json", "w") as f:
    json.dump(logs, f, indent=2)
print("✓ logs.json written")

# Export ground_truth.json
gt = {
    "anomaly_start_iso":      anomaly_start_iso,
    "anomaly_end_iso":        anomaly_end_iso,
    "anomaly_type":           "error_spike",
    "expected_behavior":      (
        "Error rate spikes from ~10% baseline to ~40% during anomaly window. "
        "http_errors_total{error_category='SYSTEM_ERROR'} counter increases sharply. "
        "Grafana error rate panel shows clear step function at anomaly_start_iso. "
        "P50 latency stays stable (error responses are fast), distinguishing "
        "this from a latency spike anomaly."
    ),
    "total_requests":         total,
    "base_requests":          len(base_logs),
    "anomaly_requests":       len(anomaly_logs),
    "base_error_rate_pct":    round(len(base_errs)/len(base_logs)*100, 2),
    "anomaly_error_rate_pct": round(len(anom_errs)/len(anomaly_logs)*100, 2),
}

with open("/home/claude/aiops-lab/traffic-generator/ground_truth.json", "w") as f:
    json.dump(gt, f, indent=2)
print("✓ ground_truth.json written")
