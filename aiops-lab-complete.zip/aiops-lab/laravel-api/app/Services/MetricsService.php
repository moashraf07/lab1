<?php

namespace App\Services;

use Illuminate\Support\Facades\Cache;

/**
 * MetricsService
 *
 * Implements Prometheus-compatible RED metrics stored in APCu/file cache.
 * Exposes: http_requests_total, http_errors_total, http_request_duration_seconds
 *
 * Design decisions:
 * - Use APCu (fast shared memory) in production; fallback to file cache in dev
 * - Labels: method, path, status/error_category only — no cardinality explosion
 * - Histogram buckets tuned to endpoint latency characteristics
 */
class MetricsService
{
    // Histogram buckets in seconds — covers 50ms → 10s range
    const BUCKETS = [0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0];

    protected string $prefix = 'prom_';

    // ─── Counter: http_requests_total ────────────────────────────────────────

    public function incrementRequestTotal(string $method, string $path, int $status): void
    {
        $key = $this->counterKey('http_requests_total', [
            'method' => $method,
            'path'   => $path,
            'status' => (string) $status,
        ]);
        $this->increment($key);
    }

    // ─── Counter: http_errors_total ──────────────────────────────────────────

    public function incrementErrorTotal(string $method, string $path, string $errorCategory): void
    {
        $key = $this->counterKey('http_errors_total', [
            'method'         => $method,
            'path'           => $path,
            'error_category' => $errorCategory,
        ]);
        $this->increment($key);
    }

    // ─── Histogram: http_request_duration_seconds ────────────────────────────

    public function observeRequestDuration(string $method, string $path, float $seconds): void
    {
        $labelStr = "method=\"{$method}\",path=\"{$path}\"";

        // Update _sum and _count
        $this->increment($this->prefix . "http_request_duration_seconds_sum|{$labelStr}", $seconds);
        $this->increment($this->prefix . "http_request_duration_seconds_count|{$labelStr}");

        // Update each bucket
        foreach (self::BUCKETS as $le) {
            if ($seconds <= $le) {
                $leStr = $this->formatLe($le);
                $this->increment($this->prefix . "http_request_duration_seconds_bucket|{$labelStr},le=\"{$leStr}\"");
            }
        }
        // +Inf bucket always increments
        $this->increment($this->prefix . "http_request_duration_seconds_bucket|{$labelStr},le=\"+Inf\"");
    }

    // ─── Render Prometheus text format ───────────────────────────────────────

    public function render(): string
    {
        $lines = [];

        // HELP + TYPE headers
        $lines[] = '# HELP http_requests_total Total number of HTTP requests';
        $lines[] = '# TYPE http_requests_total counter';
        foreach ($this->getKeys('http_requests_total') as $key => $value) {
            $labels = $this->labelsFromKey($key);
            $lines[] = "http_requests_total{{$labels}} {$value}";
        }

        $lines[] = '';
        $lines[] = '# HELP http_errors_total Total number of HTTP errors by category';
        $lines[] = '# TYPE http_errors_total counter';
        foreach ($this->getKeys('http_errors_total') as $key => $value) {
            $labels = $this->labelsFromKey($key);
            $lines[] = "http_errors_total{{$labels}} {$value}";
        }

        $lines[] = '';
        $lines[] = '# HELP http_request_duration_seconds HTTP request latency histogram';
        $lines[] = '# TYPE http_request_duration_seconds histogram';
        foreach ($this->getKeys('http_request_duration_seconds_bucket') as $key => $value) {
            $labels = $this->labelsFromKey($key);
            $lines[] = "http_request_duration_seconds_bucket{{$labels}} {$value}";
        }
        foreach ($this->getKeys('http_request_duration_seconds_sum') as $key => $value) {
            $labels = $this->labelsFromKey($key);
            $lines[] = "http_request_duration_seconds_sum{{$labels}} " . round($value, 6);
        }
        foreach ($this->getKeys('http_request_duration_seconds_count') as $key => $value) {
            $labels = $this->labelsFromKey($key);
            $lines[] = "http_request_duration_seconds_count{{$labels}} {$value}";
        }

        return implode("\n", $lines) . "\n";
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    protected function counterKey(string $metric, array $labels): string
    {
        $labelStr = implode(',', array_map(
            fn($k, $v) => "{$k}=\"{$v}\"",
            array_keys($labels),
            array_values($labels)
        ));
        return $this->prefix . "{$metric}|{$labelStr}";
    }

    protected function increment(string $key, float $amount = 1.0): void
    {
        // Use APCu if available (shared across PHP-FPM workers)
        if (function_exists('apcu_add')) {
            apcu_add($key, 0);
            apcu_inc($key, (int)($amount * 1000000)); // Store micro-units to avoid float issues
            return;
        }

        // Fallback: file-based atomic increment via Cache
        $current = Cache::get($key, 0);
        Cache::put($key, $current + $amount, now()->addDays(1));
    }

    protected function getValue(string $key): float
    {
        if (function_exists('apcu_fetch')) {
            $val = apcu_fetch($key, $success);
            return $success ? ($val / 1000000) : 0.0;
        }
        return (float) Cache::get($key, 0);
    }

    protected function getKeys(string $metric): array
    {
        $result = [];

        if (function_exists('apcu_cache_info')) {
            $info = apcu_cache_info(false);
            foreach ($info['cache_list'] ?? [] as $entry) {
                $k = $entry['info'];
                if (str_starts_with($k, $this->prefix . $metric . '|')) {
                    $result[$k] = $this->getValue($k);
                }
            }
            return $result;
        }

        // Fallback: use Laravel cache store (file) — enumerate by scanning
        // For file driver, we rely on known-key pattern from storage
        $storeDir = storage_path('framework/cache/data');
        if (is_dir($storeDir)) {
            $this->scanCacheDir($storeDir, $metric, $result);
        }

        return $result;
    }

    protected function scanCacheDir(string $dir, string $metric, array &$result): void
    {
        $files = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir));
        foreach ($files as $file) {
            if ($file->isFile()) {
                $content = @file_get_contents($file->getPathname());
                if ($content && strpos($content, $this->prefix . $metric) !== false) {
                    // Laravel cache format: serialize(expire + value)
                    $data = @unserialize(substr($content, 10));
                    if ($data !== false) {
                        // Try to extract key name from file
                        // This is best-effort for the fallback path
                    }
                }
            }
        }
    }

    protected function labelsFromKey(string $key): string
    {
        // Key format: prom_METRIC_NAME|label1="v1",label2="v2"
        $parts = explode('|', $key, 2);
        return $parts[1] ?? '';
    }

    protected function formatLe(float $le): string
    {
        // Format bucket boundary without unnecessary trailing zeros
        if ($le == (int)$le) {
            return number_format($le, 1);
        }
        return rtrim(number_format($le, 2, '.', ''), '0');
    }
}
