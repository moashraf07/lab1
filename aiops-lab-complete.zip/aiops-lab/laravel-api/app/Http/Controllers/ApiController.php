<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Services\MetricsService;
use Illuminate\Validation\ValidationException;

class ApiController extends Controller
{
    protected MetricsService $metrics;

    public function __construct(MetricsService $metrics)
    {
        $this->metrics = $metrics;
    }

    // GET /api/normal
    public function normal(Request $request)
    {
        return response()->json([
            'status'    => 'ok',
            'endpoint'  => 'normal',
            'timestamp' => now()->toIso8601String(),
            'data'      => ['message' => 'All systems nominal'],
        ]);
    }

    // GET /api/slow  (?hard=1 for 5-7s sleep → TIMEOUT_ERROR classification)
    public function slow(Request $request)
    {
        $hard = $request->boolean('hard');

        if ($hard) {
            $sleep = rand(5000000, 7000000); // 5–7 seconds in microseconds
            usleep($sleep);
        } else {
            $sleep = rand(500000, 1500000); // 0.5–1.5 seconds
            usleep($sleep);
        }

        return response()->json([
            'status'    => 'ok',
            'endpoint'  => 'slow',
            'hard'      => $hard,
            'timestamp' => now()->toIso8601String(),
            'data'      => ['message' => 'Slow response completed'],
        ]);
    }

    // GET /api/error
    public function error(Request $request)
    {
        throw new \RuntimeException('Simulated system error: upstream service unreachable');
    }

    // GET /api/random
    public function random(Request $request)
    {
        $roll = rand(1, 10);

        if ($roll <= 3) {
            throw new \RuntimeException('Random failure triggered');
        }

        if ($roll <= 5) {
            usleep(rand(200000, 800000));
        }

        return response()->json([
            'status'    => 'ok',
            'endpoint'  => 'random',
            'timestamp' => now()->toIso8601String(),
            'data'      => ['roll' => $roll, 'message' => 'Lucky this time'],
        ]);
    }

    // GET /api/db  (?fail=1 forces QueryException)
    public function db(Request $request)
    {
        $fail = $request->boolean('fail');

        if ($fail) {
            // Deliberately query a nonexistent table → throws QueryException
            DB::select('SELECT * FROM nonexistent_table_xyz LIMIT 1');
        }

        // Normal query using sqlite in-memory users table
        try {
            $results = DB::select('SELECT COUNT(*) as cnt FROM telemetry_events');
            $count   = $results[0]->cnt ?? 0;
        } catch (\Exception $e) {
            // Table not yet created – create it on first call
            DB::statement('CREATE TABLE IF NOT EXISTS telemetry_events (id INTEGER PRIMARY KEY AUTOINCREMENT, event TEXT, created_at DATETIME)');
            DB::statement("INSERT INTO telemetry_events (event, created_at) VALUES ('bootstrap', datetime('now'))");
            $count = 1;
        }

        return response()->json([
            'status'    => 'ok',
            'endpoint'  => 'db',
            'timestamp' => now()->toIso8601String(),
            'data'      => ['telemetry_event_count' => $count],
        ]);
    }

    // POST /api/validate
    public function validateInput(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'age'   => 'required|integer|between:18,60',
        ]);

        if ($validator->fails()) {
            throw new ValidationException($validator);
        }

        return response()->json([
            'status'    => 'ok',
            'endpoint'  => 'validate',
            'timestamp' => now()->toIso8601String(),
            'data'      => [
                'email'   => $request->input('email'),
                'age'     => $request->input('age'),
                'message' => 'Validation passed',
            ],
        ]);
    }

    // GET /api/metrics  (Prometheus text exposition format)
    public function metrics(Request $request)
    {
        $output = $this->metrics->render();

        return response($output, 200)
            ->header('Content-Type', 'text/plain; version=0.0.4; charset=utf-8');
    }
}
