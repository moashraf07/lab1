#!/usr/bin/env python3
"""
AIOps Lab - Controlled Traffic Generator
=========================================
Sends >=3000 requests with a realistic distribution, then injects a
2-minute anomaly window. Emits ground_truth.json and exports logs.json.
"""

import time, json, random, threading, datetime, os, sys, uuid
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from collections import defaultdict
import urllib.request, urllib.error

API_BASE   = os.getenv("API_BASE_URL", "http://localhost:8000/api")
OUTPUT_DIR = Path(os.getenv("OUTPUT_DIR", "./exports"))
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

BASE_DURATION_SECONDS    = 600
ANOMALY_DURATION_SECONDS = 120
TARGET_RPS  = 5
MAX_WORKERS = 8
ANOMALY_TYPE = os.getenv("ANOMALY_TYPE", "error_spike")

NORMAL_DISTRIBUTION = [
    ("/normal",        70, "GET",  None),
    ("/slow",          15, "GET",  None),
    ("/slow?hard=1",    5, "GET",  None),
    ("/error",          5, "GET",  None),
    ("/db",             3, "GET",  None),
    ("/validate",       2, "POST", "random"),
]
ERROR_SPIKE_DISTRIBUTION = [
    ("/normal",        45, "GET",  None),
    ("/slow",          10, "GET",  None),
    ("/slow?hard=1",    3, "GET",  None),
    ("/error",         35, "GET",  None),
    ("/db",             5, "GET",  None),
    ("/validate",       2, "POST", "random"),
]
LATENCY_SPIKE_DISTRIBUTION = [
    ("/normal",        40, "GET",  None),
    ("/slow",          15, "GET",  None),
    ("/slow?hard=1",   30, "GET",  None),
    ("/error",          5, "GET",  None),
    ("/db",             8, "GET",  None),
    ("/validate",       2, "POST", "random"),
]

log_records    = []
lock           = threading.Lock()
stats          = defaultdict(int)
anomaly_active = threading.Event()


def weighted_choice(distribution):
    endpoints = [(d[0], d[2], d[3]) for d in distribution]
    weights   = [d[1] for d in distribution]
    total = sum(weights)
    r = random.uniform(0, total)
    cum = 0
    for (ep, method, payload_fn), w in zip(endpoints, weights):
        cum += w
        if r <= cum:
            return ep, method, payload_fn
    return endpoints[-1]


def make_payload(payload_fn):
    if payload_fn is None:
        return None
    if random.random() < 0.5:
        return {"email": "not-an-email", "age": random.choice([0, -5, 17, 61])}
    return {"email": f"user{random.randint(1,9999)}@example.com", "age": random.randint(18, 60)}


def send_request(endpoint, method="GET", payload=None):
    url = f"{API_BASE}{endpoint}"
    cid = str(uuid.uuid4())
    t0  = time.time()
    headers = {
        "X-Request-Id":  cid,
        "User-Agent":    "AIOpsTrafficGen/1.0",
        "Content-Type":  "application/json",
        "Accept":        "application/json",
    }
    try:
        data = json.dumps(payload).encode() if payload else None
        req  = urllib.request.Request(url, data=data, headers=headers, method=method)
        with urllib.request.urlopen(req, timeout=15) as resp:
            lat_ms = (time.time() - t0) * 1000
            sc     = resp.getcode()
            body   = resp.read().decode("utf-8", errors="replace")
            rh     = dict(resp.headers)
        err_cat = rh.get("X-Error-Category") or rh.get("x-error-category")
        if lat_ms >= 4000 and err_cat is None:
            err_cat = "TIMEOUT_ERROR"
        return _rec(cid, endpoint, method, sc, lat_ms, err_cat, None, payload, body)
    except urllib.error.HTTPError as e:
        lat_ms = (time.time() - t0) * 1000
        try:
            parsed = json.loads(e.read().decode())
            err_cat = parsed.get("error_category", "UNKNOWN")
            err_msg = parsed.get("message", str(e))
        except Exception:
            err_cat, err_msg = "UNKNOWN", str(e)
        return _rec(cid, endpoint, method, e.code, lat_ms, err_cat, err_msg, payload, None)
    except Exception as e:
        lat_ms = (time.time() - t0) * 1000
        return _rec(cid, endpoint, method, 0, lat_ms, "SYSTEM_ERROR", str(e), payload, None)


def _rec(cid, endpoint, method, sc, lat_ms, err_cat, err_msg, payload, body):
    sev  = "error" if (sc >= 400 or sc == 0 or err_cat) else "info"
    path = endpoint.split("?")[0]
    return {
        "correlation_id":      cid,
        "host":                "traffic-generator",
        "build_version":       "1.0.0",
        "method":              method,
        "path":                path,
        "route_name":          path.strip("/").replace("/", "_") or "root",
        "query":               endpoint.split("?")[1] if "?" in endpoint else "",
        "payload_size_bytes":  len(json.dumps(payload).encode()) if payload else 0,
        "client_ip":           "127.0.0.1",
        "user_agent":          "AIOpsTrafficGen/1.0",
        "status_code":         sc,
        "response_size_bytes": len(body.encode()) if body else 0,
        "latency_ms":          round(lat_ms, 3),
        "error_category":      err_cat,
        "error_message":       err_msg,
        "severity":            sev,
        "timestamp":           datetime.datetime.utcnow().isoformat() + "Z",
        "anomaly_window":      anomaly_active.is_set(),
    }


def worker(dist):
    ep, method, pf = weighted_choice(dist)
    rec = send_request(ep, method=method, payload=make_payload(pf))
    with lock:
        log_records.append(rec)
        stats["total"] += 1
        if rec["severity"] == "error":
            stats["errors"] += 1
        stats[f"endpoint:{rec['path']}"] += 1
        if rec.get("error_category"):
            stats[f"cat:{rec['error_category']}"] += 1
    return rec


def run_phase(label, duration, dist, rps=TARGET_RPS):
    print(f"\n{'='*58}\n  PHASE: {label}\n  Duration: {duration}s | RPS: {rps}\n{'='*58}")
    end  = time.time() + duration
    sent = 0
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as ex:
        futs = []
        while time.time() < end:
            t0 = time.time()
            for _ in range(rps):
                futs.append(ex.submit(worker, dist))
                sent += 1
            futs = [f for f in futs if not f.done()]
            sleep = 1.0 - (time.time() - t0)
            if sleep > 0:
                time.sleep(sleep)
        for f in as_completed(futs, timeout=30):
            pass
    print(f"  Sent: {sent}")
    return sent


def main():
    print("AIOps Traffic Generator starting...")
    print(f"API: {API_BASE} | Anomaly: {ANOMALY_TYPE}")

    # Wait for API
    for i in range(30):
        try:
            with urllib.request.urlopen(f"{API_BASE}/normal", timeout=5) as r:
                if r.getcode() == 200:
                    print(f"[OK] API ready (attempt {i+1})")
                    break
        except Exception as e:
            print(f"[WAIT] {i+1}/30: {e}")
            time.sleep(5)
    else:
        print("[ERROR] API unavailable")
        sys.exit(1)

    base_start = datetime.datetime.utcnow().isoformat() + "Z"
    run_phase("BASE LOAD", BASE_DURATION_SECONDS, NORMAL_DISTRIBUTION)

    anomaly_start = datetime.datetime.utcnow()
    anomaly_start_iso = anomaly_start.isoformat() + "Z"
    print(f"\n!!! ANOMALY START: {anomaly_start_iso} ({ANOMALY_TYPE}) !!!")
    anomaly_active.set()

    if ANOMALY_TYPE == "error_spike":
        dist = ERROR_SPIKE_DISTRIBUTION
        expected = "Error rate on /error rises from ~5% to ~35-40%. SYSTEM_ERROR dominates."
    else:
        dist = LATENCY_SPIKE_DISTRIBUTION
        expected = "P95 latency rises sharply. TIMEOUT_ERROR category spikes. 5-10s buckets fill."

    run_phase(f"ANOMALY ({ANOMALY_TYPE})", ANOMALY_DURATION_SECONDS, dist)

    anomaly_end = datetime.datetime.utcnow()
    anomaly_end_iso = anomaly_end.isoformat() + "Z"
    anomaly_active.clear()
    print(f"\n!!! ANOMALY END: {anomaly_end_iso} !!!")

    run_phase("RECOVERY", 60, NORMAL_DISTRIBUTION)

    aw_recs = [r for r in log_records if r.get("anomaly_window")]
    gt = {
        "experiment_id":       str(uuid.uuid4()),
        "generated_at":        datetime.datetime.utcnow().isoformat() + "Z",
        "base_load_start_iso": base_start,
        "anomaly_start_iso":   anomaly_start_iso,
        "anomaly_end_iso":     anomaly_end_iso,
        "anomaly_duration_s":  ANOMALY_DURATION_SECONDS,
        "anomaly_type":        ANOMALY_TYPE,
        "expected_behavior":   expected,
        "ground_truth_metrics": {
            "total_requests":          len(log_records),
            "total_errors":            stats["errors"],
            "anomaly_window_requests": len(aw_recs),
            "anomaly_window_errors":   sum(1 for r in aw_recs if r["severity"] == "error"),
        },
        "detection_hints": {
            "error_rate_query":   "rate(http_errors_total[1m]) / rate(http_requests_total[1m])",
            "latency_p95_query":  "histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m]))",
        }
    }

    total = stats["total"]
    errors = stats["errors"]
    print(f"\n{'='*58}\n  DONE: {total} requests, {errors} errors ({100*errors/max(total,1):.1f}%)\n{'='*58}")

    with open(OUTPUT_DIR / "logs.json", "w") as f:
        json.dump(log_records, f, indent=2)
    with open(OUTPUT_DIR / "ground_truth.json", "w") as f:
        json.dump(gt, f, indent=2)

    print(f"Exported → {OUTPUT_DIR}/logs.json ({total} records)")
    print(f"Exported → {OUTPUT_DIR}/ground_truth.json")
    for k, v in sorted(stats.items()):
        print(f"  {k}: {v}")


if __name__ == "__main__":
    main()
