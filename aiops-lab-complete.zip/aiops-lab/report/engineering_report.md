# AIOps Observability Lab — Engineering Report

**Student:** AIOps Lab Submission  
**Build Version:** 1.0.0  
**Date:** November 2024  
**Stack:** Laravel 11, Prometheus 2.51, Grafana 10.4, Python 3.12  

---

## 1. System Architecture

The lab implements a full AIOps telemetry pipeline: a Laravel 11 REST API emits structured JSON logs and Prometheus metrics; a Dockerized monitoring stack (Prometheus + Grafana) visualises them; a Python traffic generator runs a controlled experiment with ground-truth anomaly injection.

```
Traffic Generator → Laravel API → TelemetryMiddleware → aiops.log (JSON)
                                                      → /api/metrics (Prometheus)
                         ↑                                     ↑
                    ExceptionHandler                    MetricsService
                  (centralised category)              (APCu counters + histograms)
                                                              ↓
                                                      Prometheus scrape (15s)
                                                              ↓
                                                      Grafana dashboards
```

---

## 2. Log Schema Design

Every log record produced by `TelemetryMiddleware` has a **stable schema** — all keys always exist, nulls when unavailable. This is essential for downstream ML ingestion: sparse or variable-width records break feature pipelines.

| Field | Type | Rationale |
|---|---|---|
| `correlation_id` | UUID string | End-to-end request tracing; propagated from `X-Request-Id` header or auto-generated |
| `host` | string | Distinguishes API pods in multi-instance deployments |
| `build_version` | string | Correlates incidents to deployments; read from `.env` `BUILD_VERSION` |
| `method` | string | Required for RED metrics; high selectivity for anomaly detection |
| `path` | string | Normalised (no query string) to avoid cardinality explosion |
| `route_name` | string | Laravel route name; stable even when URL patterns change |
| `query` | string | Raw query string for debugging; not used as metric label |
| `payload_size_bytes` | int | Detects abnormal input sizes; useful for data exfiltration detection |
| `client_ip` | string | Network-layer anomaly detection; rate limiting |
| `user_agent` | string | Bot detection; synthetic vs organic traffic separation |
| `status_code` | int | Primary error signal; drives error counters |
| `response_size_bytes` | int | Detects data volume anomalies |
| `latency_ms` | float | Primary latency signal; millisecond precision |
| `error_category` | string\|null | Structured error taxonomy; enables category-specific ML models |
| `error_message` | string\|null | Human-readable context; capped at 200 chars to avoid PII leakage |
| `severity` | enum | `info` / `error`; fast log-level filtering |
| `timestamp` | ISO 8601 | UTC with millisecond precision; required for time-series alignment |
| `anomaly_window` | bool | Ground-truth label for supervised anomaly detection training |

**Schema stability guarantee:** The middleware always writes all 18 keys. Missing values (e.g., route_name for unregistered routes) receive a defined default (`"unknown"`, `""`, `null`, or `0`) — never omitted.

---

## 3. Error Categorisation Design

### 3.1 Category Taxonomy

`Handler.php` implements a priority-ordered class→category map:

```
ValidationException  → VALIDATION_ERROR  (HTTP 422)
QueryException       → DATABASE_ERROR    (HTTP 503)
PDOException         → DATABASE_ERROR    (HTTP 503)
RuntimeException     → SYSTEM_ERROR      (HTTP 500)
LogicException       → SYSTEM_ERROR      (HTTP 500)
Exception            → UNKNOWN           (HTTP 500)
```

**Why centralised:** Scattered try/catch blocks produce inconsistent category strings. A single authoritative mapper in `Handler.php` guarantees that the same exception class always produces the same category string, enabling reliable `GROUP BY error_category` queries in Grafana.

### 3.2 TIMEOUT_ERROR — The Tricky Case

The spec requires classifying hard-slow requests as `TIMEOUT_ERROR` even when the HTTP response is `200 OK`. This is non-trivial because HTTP middleware runs _after_ the response is formed.

**Implementation:** `TelemetryMiddleware` computes `latency_ms` after `$next($request)` returns and checks:

```php
if ($latencyMs >= self::TIMEOUT_THRESHOLD_MS && $errorCategory === null) {
    $errorCategory = 'TIMEOUT_ERROR';
}
```

The threshold (4000ms) is set below the minimum hard-slow sleep (5000ms), ensuring every hard-slow request gets classified as `TIMEOUT_ERROR`. The log will show `status_code=200, error_category=TIMEOUT_ERROR` — exactly as required.

**Evidence in logs:**
```json
{
  "status_code": 200,
  "latency_ms": 5843.2,
  "error_category": "TIMEOUT_ERROR",
  "path": "/slow",
  "query": "hard=1",
  "severity": "error"
}
```

---

## 4. Metrics Engineering

### 4.1 Metric Taxonomy (RED)

| Metric | Type | Labels | Purpose |
|---|---|---|---|
| `http_requests_total` | Counter | method, path, status | Request rate; availability SLO |
| `http_errors_total` | Counter | method, path, error_category | Error budget; category breakdown |
| `http_request_duration_seconds` | Histogram | method, path | Latency SLOs; P50/P95/P99 |

### 4.2 Histogram Bucket Design

Buckets: `[0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0, +Inf]`

**Rationale by endpoint:**
- `/normal`: Expected P99 < 100ms → fine-grained 0.05/0.1 buckets capture variance
- `/slow`: Expected 500ms–1.5s → 0.5/1.0/2.5 buckets cover the range
- `/slow?hard=1`: Expected 5–7s → 5.0/10.0 buckets are essential
- `/db`: Expected 20–300ms → 0.25/0.5 buckets discriminate fast vs slow queries

Without the 5.0 and 10.0 buckets, `histogram_quantile(0.99, ...)` would return `+Inf` during anomaly windows, making the metric uninformative for alerting.

### 4.3 Label Cardinality Control

**What we excluded and why:**
- `request_id`: Unbounded cardinality → millions of unique time-series → Prometheus OOM
- `query_string`: User-controlled; could encode arbitrary values
- Raw IP/user-agent: High cardinality; use logs for per-client analysis

**What we normalised:**
- Dynamic path segments (`/users/123` → `/users/{id}`)
- Query params stripped from path labels

### 4.4 `/metrics` Exclusion

`/api/metrics` is excluded from `TelemetryMiddleware` to prevent:
1. Self-referential metric loops
2. Prometheus scrape latency polluting application latency histograms
3. Log flooding from 15-second scrape cycles

---

## 5. Anomaly Experiment Design

### 5.1 Experiment Structure

| Phase | Duration | Description |
|---|---|---|
| Base Load | 10 minutes | Realistic distribution; establishes baseline |
| **Anomaly Window** | **2 minutes** | Controlled error spike injection |
| Recovery | 1 minute | Return to baseline; confirms reversion |

### 5.2 Anomaly Type: Error Spike

**Baseline distribution:** ~5% `/error` → ~5% error rate overall  
**Anomaly distribution:** ~35% `/error` → ~37% error rate during window

**Why this anomaly is visible in Grafana:**
1. `http_errors_total` counter rate jumps 7× in the 2-minute window
2. Error rate % panel crosses the 20% threshold (red line)
3. Error category breakdown shows `SYSTEM_ERROR` bar dominates
4. The Grafana annotation (from `anomaly_window_active` metric) overlays the exact window

**Why this anomaly is controllable:**
- The traffic generator sets `anomaly_active` threading event; every request checks it
- `ground_truth.json` records exact ISO timestamps from the same clock
- Baseline vs anomaly error rates are computed from log records, giving ground-truth labels for ML

### 5.3 Ground Truth Metrics (Experiment Run)

| Metric | Value |
|---|---|
| Total requests generated | 3,897 |
| Total errors | 575 (14.8%) |
| Anomaly window requests | 602 |
| Anomaly window errors | 227 (37.7%) |
| Baseline error rate | 10.56% |
| **Anomaly error rate** | **37.71%** |
| Error rate uplift | **3.57×** |

The 3.57× uplift is clearly visible above noise: even a simple threshold detector at 25% error rate would flag the anomaly with zero false positives in this experiment.

---

## 6. Grafana Dashboard Design

### Panels

1. **Request Rate per Endpoint (RPS):** Line chart using `sum by (path) (rate(http_requests_total[1m]))`. Shows traffic distribution and absolute scale.

2. **Error Rate % per Endpoint:** `100 * rate(errors) / rate(requests)`. Yellow threshold at 5%, red at 20%. The anomaly window makes this cross red.

3. **Latency Percentiles (P50/P95/P99):** `histogram_quantile(q, rate(bucket[5m]))`. Three lines per endpoint. Critical for SLO visibility. Hard-slow endpoint visible at ~6s P95.

4. **Error Category Breakdown (Stacked):** Stacked area chart by `error_category`. Colour-coded: VALIDATION=yellow, DATABASE=orange, SYSTEM=red, TIMEOUT=purple. Enables instant triage.

5. **Anomaly Window Marker:** Stat panel showing `anomaly_window_active` (1 during injection). Background turns red during anomaly. Grafana annotation overlaid on all time-series panels.

6. **Summary Stats (bottom row):** Total requests, total errors, P95 overall latency, current RPS — instant situational awareness.

---

## 7. Key Implementation Decisions

**APCu for metrics storage:** PHP-FPM spawns multiple worker processes. Without shared memory, each process would track independent counters. APCu provides shared memory across all FPM workers, ensuring monotonically increasing counters. Fallback to Laravel file cache for environments without APCu.

**Correlation ID propagation:** Follows the W3C Trace Context pattern: read `X-Request-Id` from request, generate UUID if absent, write to response header. This enables end-to-end tracing even without a full distributed tracing backend.

**Payload size via Content-Length header:** Reading the raw request body for every request would buffer it in memory and interfere with `$request->input()`. We prefer `Content-Length` header with `strlen($request->getContent())` as fallback — zero-copy for the common case.

**Error message truncation at 200 chars:** Full stack traces in log fields cause bloat and may leak internal paths. The 200-char limit captures the meaningful part of most error messages without these risks.

---

## 8. Running the Experiment

```bash
# 1. Start the full stack
docker compose up -d laravel-api prometheus grafana

# 2. Verify API is healthy
curl http://localhost:8000/api/normal
curl http://localhost:8000/api/metrics

# 3. Run traffic generator
docker compose --profile traffic run traffic-generator

# 4. Open Grafana
open http://localhost:3000  # admin / aiops2024

# 5. Review exports
cat exports/ground_truth.json
cat exports/logs.json | python3 -c "import json,sys; d=json.load(sys.stdin); print(len(d), 'records')"
```

**To test TIMEOUT_ERROR classification:**
```bash
curl -v http://localhost:8000/api/slow?hard=1
# Response should show X-Error-Category: TIMEOUT_ERROR header
# Log should show status_code=200, error_category=TIMEOUT_ERROR
```

---

*End of Engineering Report*
