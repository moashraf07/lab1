# AIOps Observability Lab — Work 1

> **Laravel API + Prometheus + Grafana + Controlled Anomaly Injection**

## Quick Start

```bash
# 1. Clone repo and start the full stack
docker compose up --build

# 2. Wait for health checks (~15s), then run traffic generator
python3 traffic-generator/traffic_generator.py --host http://localhost:8000

# 3. Access dashboards
#    API:        http://localhost:8000/api/normal
#    Metrics:    http://localhost:8000/metrics
#    Prometheus: http://localhost:9090
#    Grafana:    http://localhost:3000  (admin / admin)
```

---

## Repository Structure

```
aiops-lab/
├── docker-compose.yml             # Full stack orchestration
├── engineering_report.pdf         # 3-page PDF report
│
├── laravel-api/                   # PHP 8.2 / Laravel 10 API
│   ├── app/
│   │   ├── Http/
│   │   │   ├── Controllers/
│   │   │   │   └── ApiController.php      # All 6 endpoints + /metrics
│   │   │   ├── Middleware/
│   │   │   │   └── TelemetryMiddleware.php # Correlation ID, latency, logs
│   │   │   └── Kernel.php                 # Global middleware registration
│   │   ├── Exceptions/
│   │   │   └── Handler.php                # Centralized error categorization
│   │   ├── Services/
│   │   │   └── MetricsRegistry.php        # Pure PHP Prometheus implementation
│   │   └── Providers/
│   │       └── AppServiceProvider.php     # Singleton binding
│   ├── routes/
│   │   ├── api.php                        # /api/* routes
│   │   └── web.php                        # / and /metrics
│   ├── config/
│   │   └── logging.php                    # aiops channel (JSON/NDJSON)
│   ├── .env                               # BUILD_VERSION, DB config
│   ├── docker/
│   │   ├── nginx.conf
│   │   └── supervisord.conf
│   └── Dockerfile
│
├── monitoring/
│   ├── prometheus/
│   │   └── prometheus.yml                 # Scrape config (15s interval)
│   └── grafana/
│       ├── dashboards/
│       │   └── aiops-dashboard.json       # Pre-built Grafana dashboard
│       └── provisioning/
│           ├── datasources/prometheus.yml
│           └── dashboards/dashboard.yml
│
└── traffic-generator/
    ├── traffic_generator.py               # Main traffic gen (run against live API)
    ├── generate_logs.py                   # Offline log generator (for submission)
    ├── logs.json                          # ≥1500 log entries with ground truth labels
    └── ground_truth.json                  # Anomaly window timestamps + stats
```

---

## API Endpoints

| Method | Endpoint | Behavior |
|--------|----------|----------|
| GET | `/api/normal` | Fast response (10–50ms) |
| GET | `/api/slow` | Slow response (1–3s) |
| GET | `/api/slow?hard=1` | Very slow (5–7s) → `TIMEOUT_ERROR` even with 200 |
| GET | `/api/error` | Throws RuntimeException → `SYSTEM_ERROR` |
| GET | `/api/random` | Randomly delegates to normal/slow/error |
| GET | `/api/db` | SQLite query success |
| GET | `/api/db?fail=1` | Forces `QueryException` → `DATABASE_ERROR` |
| POST | `/api/validate` | Validates `{email, age}` → `VALIDATION_ERROR` on bad input |
| GET | `/metrics` | Prometheus exposition format |

---

## Error Categories

All errors are mapped to stable enum strings:

| Category | Trigger |
|----------|---------|
| `VALIDATION_ERROR` | `ValidationException` from `/api/validate` |
| `DATABASE_ERROR` | `QueryException` from `/api/db?fail=1` |
| `TIMEOUT_ERROR` | Latency > 4000ms (even on HTTP 200 — see `/api/slow?hard=1`) |
| `SYSTEM_ERROR` | `RuntimeException` from `/api/error` |
| `UNKNOWN` | Any unclassified exception |

### TIMEOUT_ERROR on HTTP 200 — The Tricky Case

```
GET /api/slow?hard=1
→ sleeps 5–7 seconds
→ returns HTTP 200 {"status": "ok"}
→ TelemetryMiddleware: latency_ms=6200 > 4000 threshold
→ injects error_category = "TIMEOUT_ERROR"
→ log entry: {"status_code": 200, "error_category": "TIMEOUT_ERROR"}
```

---

## Log Schema

Every entry in `storage/logs/aiops.log` and `logs.json` has **identical keys** (nulls for missing):

```json
{
  "correlation_id":      "550e8400-e29b-41d4-a716-446655440000",
  "build_version":       "1.0.0",
  "host":                "aiops-api-1",
  "timestamp_iso":       "2025-01-15T14:05:23+00:00",
  "timestamp_unix_ms":   1736949923000,
  "method":              "GET",
  "path":                "/api/slow",
  "route_name":          "api.slow",
  "query":               "hard=1",
  "client_ip":           "172.18.0.1",
  "user_agent":          "AIOpsTrafficGenerator/1.0",
  "payload_size_bytes":  0,
  "status_code":         200,
  "response_size_bytes": 94,
  "latency_ms":          6234.871,
  "latency_sec":         6.234871,
  "severity":            "error",
  "error_category":      "TIMEOUT_ERROR",
  "error_message":       "Response latency exceeded 4000ms threshold",
  "is_anomaly_window":   false
}
```

---

## Prometheus Metrics

```
# HELP http_requests_total Total HTTP requests
# TYPE http_requests_total counter
http_requests_total{method="GET",path="/api/normal",status="200"} 1842

# HELP http_errors_total Total HTTP errors by category
# TYPE http_errors_total counter
http_errors_total{method="GET",path="/api/error",error_category="SYSTEM_ERROR"} 173

# HELP http_request_duration_seconds HTTP request latency in seconds
# TYPE http_request_duration_seconds histogram
http_request_duration_seconds_bucket{method="GET",path="/api/slow",le="5"} 234
http_request_duration_seconds_bucket{method="GET",path="/api/slow",le="10"} 267
http_request_duration_seconds_bucket{method="GET",path="/api/slow",le="+Inf"} 267
http_request_duration_seconds_sum{method="GET",path="/api/slow"} 478.234
http_request_duration_seconds_count{method="GET",path="/api/slow"} 267
```

**Histogram buckets:** `[0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0, +Inf]`

---

## Grafana Dashboard Panels

1. **Request Rate per Endpoint** — `sum(rate(http_requests_total[1m])) by (path)`
2. **Error Rate % per Endpoint** — errors / total, per path
3. **Error Category Breakdown** — stacked SYSTEM/DB/VALIDATION/TIMEOUT
4. **P50 / P95 / P99 Latency** — `histogram_quantile` per endpoint
5. **Summary Stats** — RPM, overall error rate, global P95, timeout count
6. **Anomaly Annotation** — auto-fires red vertical line when error spike detected

---

## Traffic Generator

```bash
# Full experiment (10min base + 2min anomaly)
python3 traffic-generator/traffic_generator.py \
  --host http://localhost:8000 \
  --output ./traffic-generator

# With Grafana annotation posting
python3 traffic-generator/traffic_generator.py \
  --host http://localhost:8000 \
  --grafana http://localhost:3000 \
  --grafana-key YOUR_API_KEY
```

### Traffic Distribution

| Phase | /api/normal | /api/slow | /api/slow?hard=1 | /api/error | /api/db | /api/validate |
|-------|-------------|-----------|------------------|------------|---------|---------------|
| Base  | 70% | 15% | 5% | **5%** | 3% | 2% |
| Anomaly | 42% | 8% | 3% | **40%** ← | 5% | 2% |

---

## Deliverables Checklist

- [x] `laravel-api/` — Full Laravel 10 implementation
- [x] `storage/logs/aiops.log` — NDJSON structured logs (generated at runtime)
- [x] `traffic-generator/logs.json` — ≥1500 entries, ≥100 errors, anomaly window included
- [x] `/metrics` endpoint — Prometheus text format, counters + histogram
- [x] `docker-compose.yml` — Laravel + Prometheus + Grafana
- [x] `monitoring/prometheus/prometheus.yml` — 15s scrape interval
- [x] `monitoring/grafana/dashboards/aiops-dashboard.json` — Full dashboard with all 5 required panels
- [x] `traffic-generator/traffic_generator.py` — Controlled load + anomaly injection
- [x] `traffic-generator/ground_truth.json` — Anomaly window timestamps + error rates
- [x] `engineering_report.pdf` — 3-page engineering write-up
